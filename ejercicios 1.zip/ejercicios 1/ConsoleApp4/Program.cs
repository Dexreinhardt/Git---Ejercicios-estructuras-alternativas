﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            /* 1 crear un programa que diga pida un numero entero y diga si es par o impar
            int num = 0;
            Console.Write("Introduce un numero: ");
            num = int.Parse(Console.ReadLine());
            if ((num % 2) == 0)
                Console.Write("es par.");
            else
                Console.Write("es impar");
            Console.ReadKey();
            */

            /* 2 crea un programa que pida al usuario dos numeros y diga si el primero es multiplo del segundo
            int num = 0;
            int num1 = 0;
            Console.Write("Introduce un numero: ");
            num = int.Parse(Console.ReadLine());
            Console.Write("Introduce otro numero: ");
            num1 = int.Parse(Console.ReadLine());
            if (num % num1 == 0)
                Console.Write("Son multiplos");
            else
                Console.Write("No son multiplos");
            Console.ReadKey();*/

            /* 3 crear un programa que pida al usuario un numero entero. si es multiplo de 10 se lo avisará y pedira un segundo, para decir a continuacion si este segundo tambien es multiplo de 10
            int num = 0;
            int num1 = 0;
            Console.Write("Introduce un numero: ");
            num = int.Parse(Console.ReadLine());

            if (num % 10 == 0)
            {
                Console.Write("ese numero es multiplo de 10, ahora dame otro numero: ");
                num1 = int.Parse(Console.ReadLine());
                if (num1 % 10 == 0)
                    Console.Write("ese numero tambien es multiplo de 10");
                else
                    Console.Write("El segundo numero no es multiplo de 10");
            }
            else
                Console.Write("ese numero no es multiplo de 10");
            Console.ReadKey();
                  */
            /* 4 crear un programa que pida dos numeros enteros, si el segundo es cero mostrará "error: no se puede dividir entre 0" si este no es asi mostrará el resultado de la división
            int num = 0;
            int num1 = 0;
            Console.Write("Introduce un numero: ");
            num = int.Parse(Console.ReadLine());
            Console.Write("Introduce otro numero: ");
            num1 = int.Parse(Console.ReadLine());
            if (num1 == 0)
                Console.Write("Error: No se puede dividir entre cero.");
            else
                Console.Write(num / num1);
            Console.ReadKey();
            */
            /* 5 crear un programa que pida dos numeros enteros y diga si son iguales, o en el caso contrario, el mayor de elos
            int num = 0;
            int num1 = 0;
            Console.Write("Introduce un numero: ");
            num = int.Parse(Console.ReadLine());
            Console.Write("Introduce otro numero: ");
            num1 = int.Parse(Console.ReadLine());
            if (num == num1)
                Console.Write("son iguales");
            else
                if (num1 > num)
                Console.Write(num1 + " Es mayor que " + num);
            else
                Console.Write(num + " Es mayor que " + num1);
            Console.ReadKey();
            */

            /* 6 crear un programa que pida tres numeros reales y muestre el mayor de los tres
            int num = 0;
            int num1 = 0;
            int num2 = 0;
            Console.Write("Introduce un numero: ");
            num = int.Parse(Console.ReadLine());
            Console.Write("Introduce otro numero: ");
            num1 = int.Parse(Console.ReadLine());
            Console.Write("Introduce otro numero: ");
            num2 = int.Parse(Console.ReadLine());
            if (num > num1 & num > num2)
                Console.Write(num + " Es el mayor de los tres.");
            else
            {
                if (num1 > num & num1 > num2)
                    Console.Write(num1 + " es el mayor de los tres.");
                else
                    Console.Write(num2 + " es el mayor de los tres.");
            }


            Console.ReadKey();*/



            /*Crear un programa que lea una letra tecleada por el usuario y diga si se trata de una vocal, una cifra numérica o una constante.
            char var1;
            Console.WriteLine("Introduce una consonante, vocal o numero: ");
            var1 = Convert.ToChar(Console.ReadLine());
            switch (var1)
            {
                case 'a':
                    Console.WriteLine("es una vocal");
                    break;
                case 'e':
                    Console.WriteLine("es una vocal");
                    break;
                case 'i':
                    Console.WriteLine("es una vocal");
                    break;
                case 'o':
                    Console.WriteLine("es una vocal");
                    break;
                case 'u':
                    Console.WriteLine("es una vocal");
                    break;
                case 'q':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'w':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'r':
                    Console.WriteLine("es una consonante.");
                    break;
                case 't':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'y':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'p':
                    Console.WriteLine("es una consonante.");
                    break;
                case 's':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'd':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'f':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'g':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'h':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'j':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'k':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'l':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'ñ':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'z':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'x':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'c':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'v':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'b':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'n':
                    Console.WriteLine("es una consonante.");
                    break;
                case 'm':
                    Console.WriteLine("es una consonante.");
                    break;
                case '1':
                    Console.WriteLine("es una numero");
                    break;
                case '2':
                    Console.WriteLine("es una numero");
                    break;
                case '3':
                    Console.WriteLine("es una numero");
                    break;
                case '4':
                    Console.WriteLine("es una numero");
                    break;
                case '5':
                    Console.WriteLine("es una numero");
                    break;
                case '6':
                    Console.WriteLine("es una numero");
                    break;
                case '7':
                    Console.WriteLine("es una numero");
                    break;
                case '8':
                    Console.WriteLine("es una numero");
                    break;
                case '9':
                    Console.WriteLine("es una numero");
                    break;
                default: Console.WriteLine("Lo que escribiste o es un numero, simbolo, un espacio o está en mayuscula");
                        break; } 
                Console.ReadKey();*/

            /* //8 Crear un programa que lea una letra tecleada por el usuario y diga si se trata de un signo de puntuación, una cifra numérica o algún otro carácter.
            char var1;
            Console.WriteLine("Introduce una consonante, vocal o numero: ");
            var1 = Convert.ToChar(Console.ReadLine());
            switch (var1)
            {
                case 'a':
                    Console.WriteLine("es un carácter");
                    break;
                case 'e':
                    Console.WriteLine("es un carácter");
                    break;
                case 'i':
                    Console.WriteLine("es un carácter");
                    break;
                case 'o':
                    Console.WriteLine("es un carácter");
                    break;
                case 'u':
                    Console.WriteLine("es un carácter");
                    break;
                case 'q':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'w':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'r':
                    Console.WriteLine("es un carácter.");
                    break;
                case 't':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'y':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'p':
                    Console.WriteLine("es un carácter.");
                    break;
                case 's':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'd':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'f':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'g':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'h':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'j':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'k':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'l':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'ñ':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'z':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'x':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'c':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'v':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'b':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'n':
                    Console.WriteLine("es un carácter.");
                    break;
                case 'm':
                    Console.WriteLine("es un carácter.");
                    break;
                case '1':
                    Console.WriteLine("es una numero");
                    break;
                case '2':
                    Console.WriteLine("es una numero");
                    break;
                case '3':
                    Console.WriteLine("es una numero");
                    break;
                case '4':
                    Console.WriteLine("es una numero");
                    break;
                case '5':
                    Console.WriteLine("es una numero");
                    break;
                case '6':
                    Console.WriteLine("es una numero");
                    break;
                case '7':
                    Console.WriteLine("es una numero");
                    break;
                case '8':
                    Console.WriteLine("es una numero");
                    break;
                case '9':
                    Console.WriteLine("es una numero");
                    break;
                case '.':
                    Console.WriteLine("es un simbolo");
                    break;
                case ',':
                    Console.WriteLine("es un simbolo");
                    break;
                case ';':
                    Console.WriteLine("es un simbolo");
                    break;
                case ':':
                    Console.WriteLine("es un simbolo");
                    break;
                case '-':
                    Console.WriteLine("es un simbolo");
                    break;
                case '_':
                    Console.WriteLine("es un simbolo");
                    break;
                case '{':
                    Console.WriteLine("es un simbolo");
                    break;
                case '}':
                    Console.WriteLine("es un simbolo");
                    break;
                case '¡':
                    Console.WriteLine("es un simbolo");
                    break;
                case '¿':
                    Console.WriteLine("es un simbolo");
                    break;
                case '?':
                    Console.WriteLine("es un simbolo");
                    break;
                case 'º':
                    Console.WriteLine("es un simbolo");
                    break;
                case '!':
                    Console.WriteLine("es un simbolo");
                    break;
                case '”':
                    Console.WriteLine("es un simbolo");
                    break;
                case '·':
                    Console.WriteLine("es un simbolo");
                    break;
                case '$':
                    Console.WriteLine("es un simbolo");
                    break;
                case '%':
                    Console.WriteLine("es un simbolo");
                    break;
                case '&':
                    Console.WriteLine("es un simbolo");
                    break;
                case '/':
                    Console.WriteLine("es un simbolo");
                    break;
                case '(':
                    Console.WriteLine("es un simbolo");
                    break;
                case ')':
                    Console.WriteLine("es un simbolo");
                    break;
                case '=':
                    Console.WriteLine("es un simbolo");
                    break;
                case '|':
                    Console.WriteLine("es un simbolo");
                    break;
                case '@':
                    Console.WriteLine("es un simbolo");
                    break;
                case '#':
                    Console.WriteLine("es un simbolo");
                    break;
                case '~':
                    Console.WriteLine("es un simbolo");
                    break;
                case '€':
                    Console.WriteLine("es un simbolo");
                    break;
                case '¬':
                    Console.WriteLine("es un simbolo");
                    break;
                case ']':
                    Console.WriteLine("es un simbolo");
                    break;
                case '[':
                    Console.WriteLine("es un simbolo");
                    break;

                default:
                    Console.WriteLine("Lo que escribiste o es un espacio o está en mayuscula");
                    break;
            }
            Console.ReadKey(); */

            /*
            //10 Usar el operador condicional para calcular el menor de dos números.
            int var1 = 0;
            int var2 = 0;
            Console.WriteLine("por favor introduce un numero");
            var1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("por favor introduce otro numero");
            var2 = Convert.ToInt32(Console.ReadLine());
            if (var1 > var2)
                Console.WriteLine(var1 + " Es mayor que " + var2);
            else
            { if (var2 > var1)
                    Console.WriteLine(var2 + " es mayor que " + var1);
                else
                    Console.WriteLine("Son iguales"); }
            Console.ReadKey();*/
        } 
    }
}

